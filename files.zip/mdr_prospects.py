"""
BoardIQ — HPD Multiple Dwelling Registration Prospecting Tool
==============================================================
Downloads public HPD Multiple Dwelling Registration data and outputs
a clean Excel file for any managing agent's portfolio.

HPD MDR is public data — landlords are legally required to file it.
Source: https://data.cityofnewyork.us/Housing-Development/Multiple-Dwelling-Registrations/tesw-yqqr

USAGE:
  python mdr_prospects.py --agent "AKAM"
  python mdr_prospects.py --agent "FIRSTSERVICE"
  python mdr_prospects.py --agent "DOUGLAS ELLIMAN"
  python mdr_prospects.py --all-agents   (outputs full dataset)

INSTALL:
  pip install requests pandas openpyxl

OUTPUT:
  Excel file: prospects_AKAM.xlsx  (or whatever agent name)
  Columns: Building Address, Borough, Zip, Owner Name, Owner Address,
           Head Officer Name, Managing Agent, Registration Date
"""

import requests
import argparse
import sys
import os
from datetime import datetime

try:
    import pandas as pd
except ImportError:
    print("Run: pip install pandas openpyxl")
    sys.exit(1)

NYC_MDR_API = "https://data.cityofnewyork.us/resource/tesw-yqqr.json"
NYC_MDR_CSV = "https://data.cityofnewyork.us/api/views/tesw-yqqr/rows.csv?accessType=DOWNLOAD"

BOROUGH_MAP = {
    "1": "Manhattan",
    "2": "Bronx",
    "3": "Brooklyn",
    "4": "Queens",
    "5": "Staten Island",
    "MN": "Manhattan",
    "BX": "Bronx",
    "BK": "Brooklyn",
    "QN": "Queens",
    "SI": "Staten Island",
}


def fetch_by_agent_api(agent_name: str) -> pd.DataFrame:
    """
    Fetch MDR records for a specific managing agent via API.
    Faster than downloading the full dataset.
    """
    print(f"\n📡 Fetching MDR records for agent: {agent_name}")
    print("   Source: NYC HPD Multiple Dwelling Registration (public data)")

    all_records = []
    offset = 0
    limit = 1000

    while True:
        params = {
            "$limit": limit,
            "$offset": offset,
            "$where": f"upper(managingagentcompanyname) like '%{agent_name.upper()}%'",
        }

        try:
            resp = requests.get(NYC_MDR_API, params=params, timeout=30)
            resp.raise_for_status()
            batch = resp.json()
        except requests.exceptions.ConnectionError:
            print("  ✗ Network error. Are you connected to the internet?")
            return pd.DataFrame()
        except Exception as e:
            print(f"  ✗ Error: {e}")
            return pd.DataFrame()

        if not batch:
            break

        all_records.extend(batch)
        print(f"  ✓ Fetched {len(all_records)} records so far...")

        if len(batch) < limit:
            break
        offset += limit

    if not all_records:
        print(f"  No records found for '{agent_name}'. Try a partial name like 'AKAM'.")
        return pd.DataFrame()

    return pd.DataFrame(all_records)


def fetch_full_dataset() -> pd.DataFrame:
    """Download the complete MDR dataset as CSV."""
    print("\n📡 Downloading full MDR dataset from NYC Open Data...")
    print("   This is ~70,000 buildings and may take a minute.")

    try:
        resp = requests.get(NYC_MDR_CSV, timeout=120, stream=True)
        resp.raise_for_status()

        total = 0
        chunks = []
        for chunk in resp.iter_content(chunk_size=1024*1024):
            chunks.append(chunk)
            total += len(chunk)
            print(f"  Downloaded {total / 1024 / 1024:.1f} MB...", end="\r")

        print()
        import io
        df = pd.read_csv(io.BytesIO(b"".join(chunks)), dtype=str, low_memory=False)
        print(f"  ✓ Loaded {len(df):,} records")
        return df

    except Exception as e:
        print(f"  ✗ Error: {e}")
        return pd.DataFrame()


def clean_and_enrich(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize column names, clean data, add useful derived fields.
    Handles both API (camelCase) and CSV (Title Case) column formats.
    """
    if df.empty:
        return df

    # Normalize column names to lowercase with underscores
    df.columns = [c.lower().strip().replace(" ", "_") for c in df.columns]

    # Map API field names to friendly names
    # The API returns different field names than the CSV download
    field_aliases = {
        # API names → standard names
        "buildingid":                   "building_id",
        "boroid":                       "borough_code",
        "block":                        "block",
        "lot":                          "lot",
        "bin":                          "bin",
        "communityboard":               "community_board",
        "buildingaddress":              "house_number",
        "streetname":                   "street_name",
        "postcode":                     "zip_code",
        "lifecycle":                    "lifecycle",
        "registrationid":               "registration_id",
        "registrationenddate":          "registration_end_date",
        "lastregistrationdate":         "last_registration_date",
        "ownerfirstname":               "owner_first_name",
        "ownerlastname":                "owner_last_name",
        "ownercompanyname":             "owner_company",
        "ownerhouseno":                 "owner_house_no",
        "ownerstreetname":              "owner_street",
        "ownercity":                    "owner_city",
        "ownerstate":                   "owner_state",
        "ownerzip":                     "owner_zip",
        "managingagentfirstname":       "agent_first_name",
        "managingagentlastname":        "agent_last_name",
        "managingagentcompanyname":     "managing_agent",
        "managingagenthouseno":         "agent_house_no",
        "managingagentstreetname":      "agent_street",
        "managingagentcity":            "agent_city",
        "managingagentstate":           "agent_state",
        "managingagentzip":             "agent_zip",
        "headofficerfirstname":         "officer_first_name",
        "headofficerlastname":          "officer_last_name",
        "headofficertitle":             "officer_title",
    }

    df = df.rename(columns={k: v for k, v in field_aliases.items() if k in df.columns})

    # Build clean address
    if "house_number" in df.columns and "street_name" in df.columns:
        df["address"] = (df["house_number"].fillna("") + " " +
                        df["street_name"].fillna("")).str.strip()
    elif "buildingaddress" in df.columns:
        df["address"] = df["buildingaddress"].fillna("")

    # Borough name
    if "borough_code" in df.columns:
        df["borough"] = df["borough_code"].astype(str).map(
            lambda x: BOROUGH_MAP.get(x.strip().upper(), x))
    elif "boro" in df.columns:
        df["borough"] = df["boro"].astype(str).map(
            lambda x: BOROUGH_MAP.get(x.strip().upper(), x))

    # Head officer full name (often the board president or principal)
    if "officer_first_name" in df.columns and "officer_last_name" in df.columns:
        df["head_officer"] = (df["officer_first_name"].fillna("") + " " +
                             df["officer_last_name"].fillna("")).str.strip()
    elif "headofficerfirstname" in df.columns:
        df["head_officer"] = (df["headofficerfirstname"].fillna("") + " " +
                             df.get("headofficerlastname", pd.Series([""] * len(df))).fillna("")).str.strip()

    # Officer title
    if "officer_title" in df.columns:
        df["head_officer_title"] = df["officer_title"].fillna("")

    # Managing agent full name
    if "managing_agent" not in df.columns:
        if "agent_first_name" in df.columns:
            df["managing_agent"] = (df["agent_first_name"].fillna("") + " " +
                                   df["agent_last_name"].fillna("")).str.strip()

    # Owner name
    if "owner_company" in df.columns:
        df["owner_name"] = df["owner_company"].fillna(
            (df.get("owner_first_name", pd.Series([""] * len(df))).fillna("") + " " +
             df.get("owner_last_name", pd.Series([""] * len(df))).fillna("")).str.strip()
        )
    elif "owner_first_name" in df.columns:
        df["owner_name"] = (df["owner_first_name"].fillna("") + " " +
                           df["owner_last_name"].fillna("")).str.strip()

    return df


def to_excel(df: pd.DataFrame, agent_name: str) -> str:
    """Export clean prospecting list to Excel."""

    # Select and order the most useful columns
    desired_cols = [
        "address", "borough", "zip_code",
        "head_officer", "head_officer_title",
        "owner_name",
        "managing_agent",
        "last_registration_date",
        "registration_id",
        "building_id",
        "bin",
        "block", "lot",
    ]

    available = [c for c in desired_cols if c in df.columns]
    # Add any remaining columns not in desired list
    extras = [c for c in df.columns if c not in desired_cols and c not in available]
    export_cols = available + extras[:5]  # cap extras

    export_df = df[export_cols].copy()

    # Friendly column headers
    rename_display = {
        "address": "Building Address",
        "borough": "Borough",
        "zip_code": "Zip Code",
        "head_officer": "Head Officer / Board Contact",
        "head_officer_title": "Title",
        "owner_name": "Owner Name",
        "managing_agent": "Managing Agent",
        "last_registration_date": "Last Registration",
        "registration_id": "Registration ID",
        "building_id": "Building ID",
        "bin": "BIN",
        "block": "Block",
        "lot": "Lot",
    }
    export_df = export_df.rename(columns={k: v for k, v in rename_display.items() if k in export_df.columns})

    # Sort by borough then address
    if "Borough" in export_df.columns and "Building Address" in export_df.columns:
        export_df = export_df.sort_values(["Borough", "Building Address"])

    # Write to Excel
    safe_name = agent_name.replace(" ", "_").replace("/", "-")[:30]
    filename = f"prospects_{safe_name}.xlsx"

    with pd.ExcelWriter(filename, engine="openpyxl") as writer:
        export_df.to_excel(writer, sheet_name="Buildings", index=False)

        # Auto-size columns
        ws = writer.sheets["Buildings"]
        for col in ws.columns:
            max_len = max(
                len(str(col[0].value or "")),
                max((len(str(cell.value or "")) for cell in col[1:11]), default=0)
            )
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 3, 45)

        # Add a summary sheet
        summary_data = {
            "Metric": [
                "Managing Agent Searched",
                "Total Buildings Found",
                "Manhattan Buildings",
                "Brooklyn Buildings",
                "Bronx Buildings",
                "Queens Buildings",
                "Staten Island Buildings",
                "Data Source",
                "Downloaded",
            ],
            "Value": [
                agent_name,
                len(export_df),
                len(export_df[export_df.get("Borough", pd.Series()) == "Manhattan"]) if "Borough" in export_df.columns else "N/A",
                len(export_df[export_df.get("Borough", pd.Series()) == "Brooklyn"]) if "Borough" in export_df.columns else "N/A",
                len(export_df[export_df.get("Borough", pd.Series()) == "Bronx"]) if "Borough" in export_df.columns else "N/A",
                len(export_df[export_df.get("Borough", pd.Series()) == "Queens"]) if "Borough" in export_df.columns else "N/A",
                len(export_df[export_df.get("Borough", pd.Series()) == "Staten Island"]) if "Borough" in export_df.columns else "N/A",
                "NYC HPD Multiple Dwelling Registration (public data)",
                datetime.now().strftime("%Y-%m-%d %H:%M"),
            ]
        }
        pd.DataFrame(summary_data).to_excel(writer, sheet_name="Summary", index=False)
        ws2 = writer.sheets["Summary"]
        ws2.column_dimensions["A"].width = 30
        ws2.column_dimensions["B"].width = 50

    print(f"\n✓ Saved: {filename}")
    print(f"  {len(export_df):,} buildings · {os.path.getsize(filename) / 1024:.0f} KB")
    return filename


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BoardIQ MDR Prospecting Tool")
    parser.add_argument("--agent", type=str, help="Managing agent name to search (e.g. 'AKAM')")
    parser.add_argument("--all-agents", action="store_true", help="Download full dataset")
    parser.add_argument("--list-agents", action="store_true", help="Show top managing agents by portfolio size")
    args = parser.parse_args()

    if args.list_agents:
        print("\n📊 Fetching top managing agents from MDR...")
        df = fetch_full_dataset()
        if not df.empty():
            df = clean_and_enrich(df)
            col = "managing_agent" if "managing_agent" in df.columns else df.columns[0]
            top = df[col].value_counts().head(30)
            print("\nTop 30 Managing Agents by Portfolio Size:")
            for name, count in top.items():
                print(f"  {count:>5} buildings  {name}")

    elif args.all_agents:
        df = fetch_full_dataset()
        if not df.empty:
            df = clean_and_enrich(df)
            to_excel(df, "ALL_AGENTS")

    elif args.agent:
        df = fetch_by_agent_api(args.agent)
        if not df.empty:
            df = clean_and_enrich(df)
            filename = to_excel(df, args.agent)
            print(f"\n  Open {filename} in Excel to see your prospecting list.")
            print(f"\n  Columns include:")
            print(f"    • Building address and borough")
            print(f"    • Head officer name and title (often board president)")
            print(f"    • Owner entity name")
            print(f"    • Managing agent")
            print(f"\n  To search a different agent:")
            print(f"    python mdr_prospects.py --agent \"FIRSTSERVICE\"")
            print(f"    python mdr_prospects.py --agent \"DOUGLAS ELLIMAN\"")
            print(f"    python mdr_prospects.py --agent \"CENTURY\"")
    else:
        print("Usage:")
        print("  python mdr_prospects.py --agent \"AKAM\"")
        print("  python mdr_prospects.py --agent \"FIRSTSERVICE\"")
        print("  python mdr_prospects.py --list-agents")
